#!/usr/bin/python

import os,sys,multiprocessing,json,time,re,Queue
from time import sleep
from collections import Counter,defaultdict

def wordcount(filelist):

	""" Function to find the number of words in the chunks """
	co = Counter()
        with open(filelist,"r") as frobj:
        	databuff = frobj.read().lower()
		regx = re.compile(r"[A-Za-z]+'?\w+")
		databuffer1 = regx.findall(databuff)
		co.update(databuffer1)
	print co		

if __name__ == "__main__":
	try:
        	filetoopen = sys.argv[1]
	except IndexError:
        	print "\n\n file not found \n\n"
        	exit()
	wordcount(filetoopen)
