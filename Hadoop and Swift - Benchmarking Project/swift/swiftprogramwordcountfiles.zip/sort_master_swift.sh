#!/bin/bash

echo -e "\nExecuting python file split pgm\n"

python swift_filesplit.py $1

echo -e "\nFilesplit done....\nExecuting Swift wordcount pgm\n"

swift swift_sort.swift

python swift_sort1_python.py

echo -e "\nSort done....\nExecuting Swift merge \n"

swift swift_sort_merge.swift

echo -e "\nMerge done !!\n Pgm execution complete\n" 
