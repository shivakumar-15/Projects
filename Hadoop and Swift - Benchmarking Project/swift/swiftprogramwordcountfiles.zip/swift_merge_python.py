#!/usr/bin/python
from collections import defaultdict
import re,sys

def mergefunc(filelist):
	d = defaultdict(int)
	rex = re.compile(r"{(.*)}")
	for i in filelist:
		robj = open(i,"r")
		data = robj.read()
		#rex = re.compile(r"{(.*)}")
		matched = rex.search(data)
		matched1 = "%s" % matched.group(1)
		for i in matched1.split(","):
			(k,v) = i.split(":")
			d[k] += int(v)
	print d

if __name__ == "__main__":
	filelist = sys.argv[1:]
	mergefunc(filelist)
