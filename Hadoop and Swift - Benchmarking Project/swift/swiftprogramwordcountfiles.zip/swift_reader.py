#!/usr/bin/python
import sys
filenm = open(sys.argv[1],"r")

print filenm.read()


