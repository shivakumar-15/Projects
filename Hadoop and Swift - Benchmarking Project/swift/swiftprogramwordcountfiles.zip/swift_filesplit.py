#!/usr/bin/python
import os,sys,multiprocessing,json,time,re
from time import sleep
from collections import Counter
#count = 0
filetoopen = "./"+str(sys.argv[1])
#filetoopen = "./small-dataset.txt"
def filebound():
	
	""" Divides the file into chunks """

	filebounds = []
	filebounds.append(0)
	global filetoopen 
	fsize=os.path.getsize(filetoopen)

	if fsize < 2000000:
                start = 500000
        elif fsize < 200000000:
                start = 2000000
        else:
                start = 100000000

	startptr = start
	with open(filetoopen,"r") as robj:
		while True:
			robj.seek(startptr)
			while True:
				"""Checks for space after each work or EOF"""
                		if robj.read(1) == " " or robj.read(1) == "":
                			break
                		else:
                        		pass
                	filebounds.append(robj.tell())
                	#print "robj.tell() %s" % robj.tell()
                	startptr += start
			if startptr < fsize:
				pass
			else:
				endptr = fsize - robj.tell()
				filebounds.append(endptr+robj.tell())
				break	
                	#print "startptr %s" % startptr
                	#print "filebounds %s" % filebounds
	#print filebounds
	return filebounds,[(filebounds[i],filebounds[i+1]) for i in range(len(filebounds)-1)]

def filesplit(filecrop):

	""" Splits the one big file into smaller files """

	files = []
	with open(filetoopen,"r") as robj:
		for (sptr,eptr) in filecrop:
			data = robj.read(eptr - sptr)
			with open("./splitat%s.txt" %eptr, "w") as wobj:
				wobj.write(data)
				files.append(wobj.name)
	#print robj.closed, wobj.closed
	return files				
"""
def mergeresults(c1,i):
	print "thread#%s" % i
	merge = Counter()
	mergeresults.count += 1
	print mergeresults.count
	merge.update(c1)		
	print c1
	if mergeresults.count == n:
		print "INSIDE MERGE IF:"
		json.dump(merge,open("./merged.txt","w"),indent = 2)
	else:
		pass

def wordcount(filelist):

	#Function to find the number of words in the chunks
	wordcounter = Counter()
	co = Counter()
	for i in filelist:
		#wordcounter = Counter()
		#co = Counter()
                with open(i,"r") as frobj:
			print frobj.name
                        databuff = frobj.read().lower()
			regx = re.compile("\w+'?\w+")
			databuffer1 = re.findall(regx,databuff)
			#wordcounter.update(databuffer1)
			#json.dump(wordcounter,open("./wc_split_for.txt","a"),indent = 2 )
		co.update(databuffer1)
		json.dump(co,open("./wc_split_increment.txt","a"),indent = 2 )
	json.dump(co,open("./wc_split.txt","w"),indent = 2 )
"""	
if __name__ == "__main__":
	threads = []	
	merge = Counter()
	(filebounds,filecrop) = filebound()
	print filecrop
	print filebounds
	filelist = filesplit(filecrop)
	#print filelist
	starttime = time.time()
	#wordcount(filelist)			
	endtime = time.time()
	totaltime = endtime - starttime
	print "totaltime =  %s" % totaltime

