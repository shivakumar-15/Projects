
type file;

app(file o)  filesort(file script,file input)
{
	python filename(script) filename(input) stdout = filename(o);
}

file script_file <"swift_sort_python.py">;

file filelist[] <filesys_mapper;location=".",pattern="split*",suffix=".txt">;


foreach i in filelist
{
	#file f <single_file_mapper; file=strcat("sort_",filename(i),".out")>;
	file f[] <fixed_array_mapper;files="a.txt b.txt c.txt d.txt e.txt f.txt g.txt h.txt i.txt j.txt k.txt l.txt m.txt n.txt o.txt p.txt q.txt r.txt s.txt t.txt u.txt v.txt w.txt x.txt y.txt z.txt" 
	f = filesort(script_file,i);
}
