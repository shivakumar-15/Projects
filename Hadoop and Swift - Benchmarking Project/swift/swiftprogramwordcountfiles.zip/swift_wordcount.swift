
type file;

app (file o) simplefun (file script,file fname)
{
	python filename(script) filename(fname) stdout = filename(o);
}


file script_file <"swift_wordcount_python.py">;

file filelist[] <filesys_mapper;location=".",pattern="split*",suffix=".txt">;

foreach i in filelist
{
	file f <single_file_mapper; file=strcat("output_",filename(i),".out")>;
	f = simplefun(script_file,i);
}
