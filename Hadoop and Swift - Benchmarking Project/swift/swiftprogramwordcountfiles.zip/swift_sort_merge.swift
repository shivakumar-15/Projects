type file;

app(file o) sort_merge(file script,file inputfiles[])
{
python filename(script) filenames(inputfiles) stdout = filename(o);
}

file script_file <"swit_sort_merge_python.py">;

file filelist[] <filesys_mapper;location=".",pattern="*_allwords",suffix=".txt">;
file f <"sort1MB-swift.txt">;
f = sort_merge(script_file,filelist);
