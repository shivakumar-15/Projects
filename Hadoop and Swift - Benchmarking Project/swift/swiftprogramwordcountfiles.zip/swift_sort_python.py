
#!/usr/bin/python
import sys,re
from collections import defaultdict
def filesort(filelist):

        """ Function to find the number of words in the chunks """
        for i in filelist:
                robj = open(i,"r")
                data = robj.read()
                pattern = re.compile(r"[a-z]+")
                sortedwords = pattern.findall(data)
                sortedwords.sort()
                #print sortedwords
                d = defaultdict(list)
                for i in sortedwords:
                        d[i[0]].append(i) 
                #print d.values()
                for i in d.values():
                        a =[]
                        a.extend(i)
                        strings = "\n".join([i for i in a])
			print strings
                        #with open("./%s_%s_allwords.txt" % (a[0][0],X),"a") as wobj:
                               # wobj.write(strings)

if __name__ == "__main__":

	fname = sys.argv[1]
	filesort([fname])
