#!/usr/bin/python
import os,sys,multiprocessing,json,time,re
from time import sleep
from collections import Counter
"""
def filebound():
	
	 #Divides the file into chunks

	filebounds = []
	filebounds.append(0)
	global filetoopen 
	fsize=os.path.getsize(filetoopen)
	  
	start = 300000000
	startptr = start
	with open(filetoopen,"r") as robj:
		while True:
			robj.seek(startptr)
			while True:
				#Checks for space after each work or EOF
                		if robj.read(1) == " " or robj.read(1) == "":
                			break
                		else:
                        		pass
                	filebounds.append(robj.tell())
                	startptr += start
			if startptr < fsize:
				pass
			else:
				endptr = fsize - robj.tell()
				filebounds.append(endptr+robj.tell())
				break	
	return filebounds,[(filebounds[i],filebounds[i+1]) for i in range(len(filebounds)-1)]

def filesplit(filecrop):

	#Splits the one big file into smaller files

	files = []
	with open(filetoopen,"r") as robj:
		for (sptr,eptr) in filecrop:
			data = robj.read(eptr - sptr)
			with open("./splitat%s.txt" %eptr, "w") as wobj:
				wobj.write(data)
				files.append(wobj.name)
	#print robj.closed, wobj.closed
	return files				
"""
def wordcount(filelist):

	""" Function to find the number of words in the chunks """
	co = Counter()
	for i in filelist:
                with open(i,"r") as frobj:
			print frobj.name
                        databuff = frobj.read().lower()
			regx = re.compile("\w+'?\w+")
			databuffer1 = re.findall(regx,databuff)
		co.update(databuffer1)
		json.dump(co,open("./wc_split_increment.txt","a"),indent = 2 )
	json.dump(co,open("./wc_split.txt","w"),indent = 2 )
	
if __name__ == "__main__":

	#(filebounds,filecrop) = filebound()
	#filelist = filesplit(filecrop)
	filelist = [sys.argv[1]]
	print filelist
	starttime = time.time()
	wordcount(filelist)			
	endtime = time.time()
	totaltime = endtime - starttime
	print "totaltime =  %s" % totaltime

