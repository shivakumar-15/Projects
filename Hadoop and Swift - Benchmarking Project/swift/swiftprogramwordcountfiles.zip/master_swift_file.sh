#!/bin/bash

echo -e "\nExecuting python file split pgm\n"

python swift_filesplit.py $1

echo -e "\nFilesplit done....\nExecuting Swift wordcount pgm\n"

swift swift_wordcount.swift

echo -e "\nWordcount done....\nExecuting Swift merge pgm\n"

swift swift_merge.swift

echo -e "\nMerge done !!\n Pgm execution complete\n" 
