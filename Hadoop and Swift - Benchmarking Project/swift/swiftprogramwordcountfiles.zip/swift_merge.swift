type file;

app(file o) mergecount (file script,file listoffiles[]) //can listoffiles be an array
{
	python filename(script) filenames(listoffiles) stdout = filename(o);
}

file script_file <"swift_merge_python.py">;

file filelist[] <filesys_mapper;location="./output_.",pattern="split*",suffix=".txt.out">;
file f <"merged_output.swt">;
f = mergecount(script_file,filelist);

